#ifndef MAIN_H
#define MAIN_H

#include "gba.h"

typedef struct  {
    int x;
    int y;
    int speed;
    int width;
    int height;
} Player;

typedef struct  {
    int x;
    int y;
    int speed;
    int width;
    int height;
} Lava;

#endif
