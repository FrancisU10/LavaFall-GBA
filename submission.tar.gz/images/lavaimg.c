/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x5 lavaimg lavaimg.png 
 * Time-stamp: Friday 04/04/2025, 09:19:48
 * 
 * Image Information
 * -----------------
 * lavaimg.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "lavaimg.h"

const unsigned short lavaimg[25] =
{
	0x01ff,0x063f,0x1aff,0x0e7f,0x0a3f,0x025f,0x069f,0x0ebf,0x0a7f,0x05bf,0x027f,0x069f,0x065f,0x067f,0x01df,0x01ff,
	0x027f,0x065f,0x065f,0x05df,0x01df,0x021f,0x01bf,0x019f,0x00fe
};

