/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 volcano Volcano1.png 
 * Time-stamp: Friday 04/04/2025, 07:19:08
 * 
 * Image Information
 * -----------------
 * Volcano1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VOLCANO_H
#define VOLCANO_H

extern const unsigned short Volcano1[38400];
#define VOLCANO1_SIZE 76800
#define VOLCANO1_LENGTH 38400
#define VOLCANO1_WIDTH 240
#define VOLCANO1_HEIGHT 160

#endif

