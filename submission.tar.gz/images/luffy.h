/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=24x24 luffy luffy.png 
 * Time-stamp: Friday 04/04/2025, 07:23:32
 * 
 * Image Information
 * -----------------
 * luffy.png 24@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LUFFY_H
#define LUFFY_H

extern const unsigned short luffy[576];
#define LUFFY_SIZE 1152
#define LUFFY_LENGTH 576
#define LUFFY_WIDTH 24
#define LUFFY_HEIGHT 24

#endif

