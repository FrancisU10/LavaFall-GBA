/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=5x5 lavaimg lavaimg.png 
 * Time-stamp: Friday 04/04/2025, 09:19:48
 * 
 * Image Information
 * -----------------
 * lavaimg.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LAVAIMG_H
#define LAVAIMG_H

extern const unsigned short lavaimg[25];
#define LAVAIMG_SIZE 50
#define LAVAIMG_LENGTH 25
#define LAVAIMG_WIDTH 5
#define LAVAIMG_HEIGHT 5

#endif

